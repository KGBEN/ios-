//
//  EnemyView.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "EnemyView.h"

@implementation EnemyView

// 提示，参数enemy应该在视图控制器中实例化完成，在此辅助图像视图的外观建立
- (id)initWithEnemy:(Enemy *)enemy imageRes:(ImageResources *)imageRes
{
    self = [super init];
    
    if (self) {
        self.enemy = enemy;
        
        // 根据敌机类型设置敌机的相关图像
        switch (self.enemy.type) {
            case kEnemySmall:
                // 图像
                self.image = imageRes.enemySmallImage;
                // 爆炸图像
                self.blowupImages = imageRes.enemySmallBlowupImages;
                
                break;
            case kEnemyMiddle:
                // 图像
                self.image = imageRes.enemyMiddleImage;
                // 爆炸
                self.blowupImages = imageRes.enemyMiddleBlowupImages;
                // 挨揍
                self.hitImage = imageRes.enemyMiddleHitImage;
                
                break;
            case kEnemyBig:
                // 图像
                self.image = imageRes.enemyBigImages[0];
                // 因为大飞机有多张图片，需要播放序列帧动画
                self.animationImages = imageRes.enemyBigImages;
                self.animationDuration = 0.5f;
                // 播放序列帧动画
                [self startAnimating];
                
                // 爆炸
                self.blowupImages = imageRes.enemyBigBlowupImages;
                // 挨揍
                self.hitImage = imageRes.enemyBigHitImage;
                
                break;
            case kEnemyBoss:
                // 图像
                self.image = imageRes.enemyBossImages[0];
                // 因为boss有多张图片，需要播放序列帧动画
                self.animationImages = imageRes.enemyBossImages;
                self.animationDuration = 0.5f;
                // 播放序列帧动画
                [self startAnimating];
                // 爆炸
                self.blowupImages = imageRes.enemyBossBlowupImages;
                // 挨揍
                self.hitImage = imageRes.enemyBossHitImage;
                
            break;
        }
        
        // 设定图像视图的frame和center
        [self setFrame:CGRectMake(0, 0, self.image.size.width, self.image.size.height)];
        [self setCenter:enemy.position];
    }
    
    return self;
}
@end
