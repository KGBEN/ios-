//
//  HeroView.h
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroView : UIImageView

- (id)initWithImages:(NSArray *)images;

@end
