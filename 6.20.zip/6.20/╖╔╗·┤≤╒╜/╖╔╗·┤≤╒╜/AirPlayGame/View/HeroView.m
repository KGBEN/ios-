//
//  HeroView.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "HeroView.h"

@implementation HeroView

// 参数：飞行的图像数组
- (id)initWithImages:(NSArray *)images
{
    self = [super initWithImage:images[0]];
    
    if (self) {
        // 设置序列帧动画
        [self setAnimationImages:images];
        // 设置播放时长
        [self setAnimationDuration:1.0];
        // 启动动画
        [self startAnimating];
    }
    
    return self;
}

@end
