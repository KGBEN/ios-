//
//  TitleView.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "TitleView.h"

@implementation TitleView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // 1. 显示背景图片
        UIImage *bgImage = [UIImage imageNamed:@"images.bundle/background_2.png"];
        UIImageView *bg = [[UIImageView alloc]initWithImage:bgImage];
        [bg setFrame:self.frame];
        [self addSubview:bg];
        
        // 2. 显示标题图片
        UIImage *titleImage = [UIImage imageNamed:@"images.bundle/BurstAircraftLogo.png"];
        UIImageView *titleView = [[UIImageView alloc]initWithImage:titleImage];
        [titleView setCenter:self.center];
        [self addSubview:titleView];
        //在屏幕中间
    }
    return self;
}

@end
