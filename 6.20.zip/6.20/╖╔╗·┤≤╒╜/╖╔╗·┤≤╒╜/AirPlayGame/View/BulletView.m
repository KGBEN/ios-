//
//  BulletView.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "BulletView.h"

@implementation BulletView

- (id)initWithImage:(UIImage *)image bullet:(Bullet *)bullet
{
    self = [super initWithImage:image];
    if (self) {
        self.bullet = bullet;
    }
    
    return self;
}


@end
