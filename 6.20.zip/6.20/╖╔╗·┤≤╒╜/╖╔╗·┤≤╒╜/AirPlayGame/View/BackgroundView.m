//
//  BackgroundView.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "BackgroundView.h"

@interface BackgroundView()

@property (weak, nonatomic) UIImageView *bg1;
@property (weak, nonatomic) UIImageView *bg2;

@end

@implementation BackgroundView

- (id)initWithFrame:(CGRect)frame image:(UIImage *)image
{
    self = [super initWithFrame:frame];
    
    if (self) {
        // 实例化图片
        UIImageView *bg1 = [[UIImageView alloc]initWithImage:image];
        [self addSubview:bg1];
        self.bg1 = bg1;
        
        UIImageView *bg2 = [[UIImageView alloc]initWithImage:image];
        [self addSubview:bg2];
        self.bg2 = bg2;
    }
    
    return self;
}

#pragma mark - 更新背景图片位置
- (void)changBGWithFrame1:(CGRect)frame1 rame2:(CGRect)frame2
{
    [self.bg1 setFrame:frame1];
    [self.bg2 setFrame:frame2];
}

@end
