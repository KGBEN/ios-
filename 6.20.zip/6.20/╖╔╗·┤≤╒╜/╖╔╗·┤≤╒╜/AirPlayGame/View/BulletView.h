//
//  BulletView.h
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Bullet.h"

@interface BulletView : UIImageView

// 记录该颗子弹的模型对象，方便后续的子弹打飞机等逻辑的处理
@property (strong, nonatomic) Bullet *bullet;

- (id)initWithImage:(UIImage *)image bullet:(Bullet *)bullet;

@end
