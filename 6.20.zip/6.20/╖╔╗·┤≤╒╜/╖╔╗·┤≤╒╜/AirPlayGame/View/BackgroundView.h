//
//  BackgroundView.h
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BackgroundView : UIView

- (id)initWithFrame:(CGRect)frame image:(UIImage *)image;

#pragma mark = 更新背景图片位置
- (void)changBGWithFrame1:(CGRect)frame1 rame2:(CGRect)frame2;

@end
