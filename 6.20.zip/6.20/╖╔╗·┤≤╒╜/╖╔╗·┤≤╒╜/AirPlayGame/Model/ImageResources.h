//
//  ImageResources.h
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageResources : NSObject

#pragma mark 背景图片
@property (strong, nonatomic) UIImage *bgImage;

#pragma mark 英雄图片
// 飞行数组
@property (strong, nonatomic) NSArray *heroFlyImages;
// 爆炸数组
@property (strong, nonatomic) NSArray *heroBlowupImages;

#pragma mark 子弹图片
// 普通子弹
@property (strong, nonatomic) UIImage *bullteNormalImage;
// 加强子弹
@property (strong, nonatomic) UIImage *bullteEnhancedImage;

#pragma mark 敌机图片
// 小飞机飞行图像
@property (strong, nonatomic) UIImage *enemySmallImage;
// 小飞机爆炸数组
@property (strong, nonatomic) NSArray *enemySmallBlowupImages;
// 中飞机飞行图像
@property (strong, nonatomic) UIImage *enemyMiddleImage;
// 中飞机爆炸数组
@property (strong, nonatomic) NSArray *enemyMiddleBlowupImages;
// 中飞机挨揍图像
@property (strong, nonatomic) UIImage *enemyMiddleHitImage;
// 大飞机飞行数组
@property (strong, nonatomic) NSArray *enemyBigImages;
// 大飞机爆炸数组
@property (strong, nonatomic) NSArray *enemyBigBlowupImages;
// 大飞机挨揍图像
@property (strong, nonatomic) UIImage *enemyBigHitImage;
// boss飞机飞行数组
@property (strong, nonatomic) NSArray *enemyBossImages;
// boss飞机爆炸数组
@property (strong, nonatomic) NSArray *enemyBossBlowupImages;
// boss飞机挨揍图像
@property (strong, nonatomic) UIImage *enemyBossHitImage;

@end
