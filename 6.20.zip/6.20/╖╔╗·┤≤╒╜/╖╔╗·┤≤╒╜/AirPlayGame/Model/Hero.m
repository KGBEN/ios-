//
//  Hero.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "Hero.h"
#import "Bullet.h"

// 每次发射子弹的颗数
#define kFireCount  1

@implementation Hero

#pragma mark - 工厂方法
+ (id)heroWithSize:(CGSize)size gameArea:(CGRect)gameArea
{
    Hero *h = [[Hero alloc]init];
    
    // 计算位置
    CGFloat x = gameArea.size.width / 2;
    // y方向预留了半个机身
    CGFloat y = gameArea.size.height - size.height;
    
    h.positon = CGPointMake(x, y);
    h.size = size;
    
    h.bombCount = 0;
    h.isEnhancedBullet = NO;
    h.enhancedTime = 0;
 
    // 实例化子弹集合，因为子弹发射的频率非常高！所以保存子弹的集合不适合用懒加载的方式
    h.bullteSet = [NSMutableSet set];
    
    return h;
}

#pragma mark 碰撞检测使用的frame，getter方法
- (CGRect)collisionFrame
{
    CGFloat x = self.positon.x - self.size.width / 4.0;
    CGFloat y = self.positon.y - self.size.height / 2.0;
	CGFloat w = self.size.width / 2.0;
    CGFloat h = self.size.height;
    
    return CGRectMake(x, y, w, h);
}

#pragma mark - 成员方法
// 发射子弹
// 发射子弹之前，需要指定bullteNormalSize 和 bullteEnhancedSize
- (void)fire
{
    // 循环发射子弹，意味着创建kFireCount个子弹的实例
    // 需要根据子弹是否加强，计算当前使用子弹的大小
    CGSize bullteSize = self.bullteNormalSize;
    if (self.isEnhancedBullet) {
        bullteSize = self.bullteEnhancedSize;
    }

    // 计算第一颗子弹的y坐标
    CGFloat y = self.positon.y - self.size.height / 2 - bullteSize.height / 2;
    CGFloat x = self.positon.x;
    
    self.isEnhancedBullet = NO;
    
    for (NSInteger i = 0; i < kFireCount; i++) {
        CGPoint p = CGPointMake(x, y - i * bullteSize.height * 2);
        Bullet *b = [Bullet bulletWithPosition:p
                                    isEnhanced:self.isEnhancedBullet];
        [self.bullteSet addObject:b];
    }
}

@end
