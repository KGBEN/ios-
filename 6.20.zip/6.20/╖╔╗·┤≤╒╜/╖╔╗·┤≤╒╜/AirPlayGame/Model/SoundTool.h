//
//  SoundTool.h
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//
/*  声音工具，预加载背景音乐（长时间播放，可以循环播放）和音效（短时间播放，点缀游戏氛围）**/

#import <Foundation/Foundation.h>

@interface SoundTool : NSObject

#pragma mark - 播放背景音乐
- (void)playMusic;
- (void)pauseMusic;

#pragma mark - 播放指定名称的音效
- (void)playSoundByFileName:(NSString *)fileName;

@end
