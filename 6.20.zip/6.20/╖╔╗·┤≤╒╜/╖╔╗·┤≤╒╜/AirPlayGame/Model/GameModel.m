//
//  GameModel.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "GameModel.h"

@implementation GameModel

#pragma mark - 工厂方法
+ (id)gameModelWithArea:(CGRect)gameArea heroSize:(CGSize)heroSize
{
    GameModel *m = [[GameModel alloc]init];
    
    m.gameArea = gameArea;
    
    // 背景图片的边框
    m.bgFrame1 = gameArea;
    m.bgFrame2 = CGRectOffset(gameArea, 0, -gameArea.size.height);
    
    // 实例化英雄，英雄是独一无二的，可以针对该对象，对工厂方法进行扩展
    m.hero = [Hero heroWithSize:heroSize gameArea:gameArea];
    
    // 默认得分为0
    m.score = 0;
    
    return m;
}

#pragma mark 背景图片向下移动
- (void)bgMoveDown
{
    // 两张背景统一向下移动一点
    self.bgFrame1 = CGRectOffset(self.bgFrame1, 0, 1);
    self.bgFrame2 = CGRectOffset(self.bgFrame2, 0, 1);
    
    // 如果背景图片已经从游戏区域下方移出，将其调整至游戏区域上方
    CGRect topFrame = CGRectOffset(self.gameArea, 0, -self.gameArea.size.height);
    
    if (self.bgFrame1.origin.y >= self.gameArea.size.height) {
        self.bgFrame1 = topFrame;
    }
    if (self.bgFrame2.origin.y >= self.gameArea.size.height) {
        self.bgFrame2 = topFrame;
    }
}

#pragma mark - 创建敌机
- (Enemy *)createEnemyWithType:(EnemyType)type size:(CGSize)size
{
    return [Enemy enemyWithType:type size:size gameArea:self.gameArea];
}

@end
