//
//  Bullet.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "Bullet.h"

#define kDamageNormal       1
#define kDamageEnhanced     2

@implementation Bullet

+ (id)bulletWithPosition:(CGPoint)positon isEnhanced:(BOOL)isEnhanced
{
    Bullet *b = [[Bullet alloc]init];
    b.position = positon;
    b.isEnhanced = isEnhanced;
    b.damage = isEnhanced ?
    //1 : 1;
    kDamageEnhanced : kDamageNormal;
    //b.damage = 0.1;
    return b;
}

@end
