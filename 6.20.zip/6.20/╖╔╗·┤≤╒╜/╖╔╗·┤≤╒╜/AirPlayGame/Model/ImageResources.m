//
//  ImageResources.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "ImageResources.h"

@implementation ImageResources

#pragma mark - 私有方法
#pragma mark 从指定bundle中加载图像
- (UIImage *)loadImageWithBundle:(NSBundle *)bundle imageName:(NSString *)imageName
{
    // 从images.bundle中加载指定文件名的图像
    NSString *path = [bundle pathForResource:imageName ofType:@"png"];
    
    return [UIImage imageWithContentsOfFile:path];
}

#pragma mark 从指定bundle中加载序列帧图像数组
// 参数：format 就是文件名的格式字符串
- (NSArray *)loadImagesWithBundle:(NSBundle *)bundle format:(NSString *)format count:(NSInteger)count
{
    NSMutableArray *arrayM = [NSMutableArray arrayWithCapacity:count];
    
    for (NSInteger i = 1; i <= count; i++) {
        NSString *imageName = [NSString stringWithFormat:format, i];
        
        UIImage *image = [self loadImageWithBundle:bundle imageName:imageName];
        
        [arrayM addObject:image];
    }
    
    return arrayM;
}

#pragma mark - 对象方法
- (id)init
{
    self = [super init];
    
    if (self) {
        // 加载图片资源，在游戏开发中，对于游戏视图中需要使用到图像资源，最好不要用缓存
        // 1. 实例化bundle
        // 1） 取出images.bundle的bundle路径
        NSString *bundlePath = [[[NSBundle mainBundle]bundlePath]stringByAppendingPathComponent:@"images.bundle"];
        // 2) 建立images.bundle的包
        NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
        
        // 2. 加载背景图片
        self.bgImage = [self loadImageWithBundle:bundle imageName:@"background_2"];
        
        // 3. 加载英雄飞行图片
        self.heroFlyImages = [self loadImagesWithBundle:bundle
                                                 format:@"hero_fly_%d"
                                                  count:6];
        self.heroBlowupImages = [self loadImagesWithBundle:bundle format:@"hero_blowup_%d" count:7];
        
        // 4. 子弹图片
        self.bullteNormalImage = [self loadImageWithBundle:bundle imageName:@"bullet2"];
        self.bullteEnhancedImage = [self loadImageWithBundle:bundle imageName:@"bullet3"];
        
        // 5. 小飞机
        self.enemySmallImage = [self loadImageWithBundle:bundle imageName:@"enemy1_fly_1"];
        self.enemySmallBlowupImages = [self loadImagesWithBundle:bundle format:@"enemy1_blowup_%d" count:4];
        
        // 6. 中飞机
        self.enemyMiddleImage = [self loadImageWithBundle:bundle imageName:@"enemy3_fly_1"];
        self.enemyMiddleHitImage = [self loadImageWithBundle:bundle imageName:@"enemy3_hit_1"];
        self.enemyMiddleBlowupImages = [self loadImagesWithBundle:bundle format:@"enemy3_blowup_%d" count:4];
        
        // 7. 大飞机
        self.enemyBigImages = [self loadImagesWithBundle:bundle format:@"enemy2_fly_%d" count:2];
        self.enemyBigHitImage = [self loadImageWithBundle:bundle imageName:@"enemy2_hit_1"];
        self.enemyBigBlowupImages = [self loadImagesWithBundle:bundle format:@"enemy2_blowup_%d" count:7];
        // 8.Boss
        self.enemyBossImages = [self loadImagesWithBundle:bundle format:@"hero_fly_%d" count:2];
        self.enemyBossHitImage = [self loadImageWithBundle:bundle  imageName:@"hero_blowup_2" ];
        self.enemyBossBlowupImages = [self loadImagesWithBundle:bundle format:@"hero_blowup_%d" count:4];
    }
    
    return self;
}

@end
