//
//  Enemy.h
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/7.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    kEnemySmall = 0,
    kEnemyMiddle,
    kEnemyBig,
    kEnemyBoss,
} EnemyType;

@interface Enemy : NSObject

#pragma mark - 工厂方法
// 根据游戏时钟触发，来连续增加到游戏中，例如：每秒增加3架敌机
// 敌机的类型不同，大小不同，默认出现的位置都在游戏视图的正上方水平随机位置，等待进入屏幕
// 工厂方法中，需要传入不同类型的敌机尺寸
// 通过整理，需要传入：敌机类型、敌机尺寸、游戏区域
+ (id)enemyWithType:(EnemyType)type size:(CGSize)size gameArea:(CGRect)gameArea;

#pragma mark - 敌机属性
// 类型（小、中、大、boss）
@property (assign, nonatomic) EnemyType type;
// 位置
@property (assign, nonatomic) CGPoint position;
// 生命值（不是所有的敌机都能一枪干掉）
@property (assign, nonatomic) NSInteger hp;
// 速度
@property (assign, nonatomic) NSInteger speed;
// 得分
@property (assign, nonatomic) NSInteger score;

// 飞机爆炸标示，如果为真，标示飞机要爆炸，供碰撞检测使用
@property (assign, nonatomic) BOOL toBlowup;
// 爆炸动画已经播放的帧数
@property (assign, nonatomic) NSInteger blowupFrames;


@end
