//
//  ViewController.m
//  飞机大战
//
//  Created by 刘国志雄 on 2020/6/6.
//  Copyright © 2020年 刘国志雄. All rights reserved.
//

#import "ViewController.h"
#import "LoadingView.h"
#import "TitleView.h"
#import "AirPlayGameViewController.h"
#import "GameModel.h"

@interface ViewController ()

// 加载视图
@property (weak, nonatomic) LoadingView *loadingView;
// 标题视图
@property (weak, nonatomic) TitleView *titleView;
// 按钮视图
@property (weak,nonatomic) TitleView *startButton;

// 游戏视图控制器
@property (strong, nonatomic) AirPlayGameViewController *gameController;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor blackColor];
    
    // 显示加载视图
    LoadingView *loadingView = [[LoadingView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:loadingView];
    self.loadingView = loadingView;
    
    // 用后台方式，加载游戏素材资源
    // performSelectorInBackground通常用于在后台执行一些相对耗时的工作，同时不阻塞前端的主线程执行
    [self performSelectorInBackground:@selector(loadRresources) withObject:nil];
}

#pragma mark - 私有方法
#pragma mark 后台加载素材
- (void)loadRresources
{
    // 1. 加载资源
    // 模拟加载素材的过程，保证能够看到加载视图
    // 使用线程睡眠的方法，通常在实际游戏开发过程中，不要使用此方法
    [NSThread sleepForTimeInterval:2.0];
    NSLog(@"加载资源...");
    // 实例化游戏视图控制器
    self.gameController = [[AirPlayGameViewController alloc]init];
    [self.gameController loadResources];
    
    // 2. 删除LoadingView
    [self.loadingView removeFromSuperview];
    
    // 3. 显示标题视图
    TitleView *titleView = [[TitleView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:titleView];
    self.titleView = titleView;
    //4.创建开始游戏btn
    UIButton *startButton = [ UIButton buttonWithType:UIButtonTypeCustom];
        startButton.frame = CGRectMake(150, 470,110, 45);//(x,y,w,h)
    [startButton setImage: [UIImage imageNamed:@"images.bundle/start_button_1.png"] forState:UIControlStateNormal];
    [startButton setImage:[UIImage imageNamed:@"A.png"] forState:UIControlStateHighlighted];//不知道为什么命名为start_button_2.png就加载不了-lgzx
    [self.view addSubview:startButton];
    self.startButton = startButton;
    // 5. 按下开始游戏btn时，在后台调用beginGame方法，当游戏素材准备就绪后，进入游戏
    [startButton addTarget:self action:@selector(beginGame) forControlEvents:UIControlEventTouchUpInside];
    //[self performSelectorInBackground:@selector(beginGame) withObject:nil];
}

// 进入游戏
- (void)beginGame
{
    // 1. 停留1秒删除标题视图，在进入游戏之前，需要给用户一个准备时间
    [NSThread sleepForTimeInterval:2.0f];
    [self.titleView removeFromSuperview];
    [self.startButton removeFromSuperview];
    
    // 3. 显示游戏视图控制器
    [self.view addSubview:self.gameController.view];
}


@end
