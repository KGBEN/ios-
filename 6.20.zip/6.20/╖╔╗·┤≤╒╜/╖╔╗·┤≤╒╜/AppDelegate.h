//
//  AppDelegate.h
//  飞机大战
//
//  Created by sfk-ios on 2017/12/1.
//  Copyright © 2017年 sfk-JasonSu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

