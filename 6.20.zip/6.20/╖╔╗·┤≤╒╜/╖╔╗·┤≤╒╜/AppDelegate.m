//
//  AppDelegate.m
//  飞机大战
//
//  Created by sfk-ios on 2017/12/1.
//  Copyright © 2017年 sfk-JasonSu. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"DidEnterBackground" object:nil];
}

@end
